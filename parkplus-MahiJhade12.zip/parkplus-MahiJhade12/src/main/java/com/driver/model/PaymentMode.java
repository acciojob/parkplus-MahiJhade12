package com.driver.model;

public enum PaymentMode {

    CASH, CARD, UPI
}