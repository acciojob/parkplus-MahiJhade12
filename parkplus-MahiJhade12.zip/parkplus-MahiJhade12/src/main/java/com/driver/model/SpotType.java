package com.driver.model;

public enum SpotType {

    TWO_WHEELER, FOUR_WHEELER, OTHERS
}
